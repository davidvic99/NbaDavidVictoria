<?php

require_once('../src/equipo.php');
require_once('../public/assets/navSup.php');

$equipo = new equipo();
$equipo->conectar();  
$resultado = $equipo->listaEquipos();  

$i=0;
while($todo=mysqli_fetch_assoc($resultado)){

  $nombre[] = $todo['Nombre']; 
  $ciudad[] = $todo['Ciudad'];
  $Conferencia[] =$todo['Conferencia'];
  $division[]=$todo['Division'];
  echo "$nombre[$i] $ciudad[$i] $Conferencia[$i] $division[$i] <br> ";
  $i++;
}


?>
<link rel="stylesheet" href="./css/nba.css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">